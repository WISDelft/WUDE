/*
Phantom Readability Library for Java
Copyright (C) 2009 Niels Ott

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/


package de.drni.readability.demo.gui;

import java.text.DecimalFormat;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.text.BadLocationException;
import javax.swing.text.Document;
import javax.swing.text.PlainDocument;

import de.drni.readability.phantom.Readability;

/**
 * A simple model-alike class for the Readability Panel. This is
 * inspired by the Document-View pattern, however there is not
 *  such a clear separation of the components.
 * @author Niels Ott
 * @version $Id: PanelModel.java 593 2009-07-14 13:37:55Z nott@SFS.UNI-TUEBINGEN.DE $
 */
public class PanelModel {

	/**
	 * The format for the numbers in the result table.
	 */
	public static final DecimalFormat format = new DecimalFormat("######.####");
	private ReadOnlyTableModel tableModel;
	private PlainDocument documentModel;
	
	/**
	 * An internal table model used for JTable.
	 * This only ensures that the table is read-only.
	 */
	private class ReadOnlyTableModel extends DefaultTableModel {

		private static final long serialVersionUID = -7532723028306852467L;

		public ReadOnlyTableModel(Object[][] values, Object[] colnames) {
			super(values, colnames);
		}

		@Override
		public boolean isCellEditable(int row, int column) {
			return false;
		}

	}
	
	/**
	 * Constructs a new model. The result table will be set
	 * up so that the names of the readability measures are present
	 * and the results column is empty.
	 */
	public PanelModel() {
		
		// initialize names column
		String[][] values = new String[8][2];
		values[0][0] = "Automated Readability Index (ARI)";
		values[1][0] = "Coleman-Liau Index";
		values[2][0] = "Flesch-Kincaid";
		values[3][0] = "Flesch Reading Ease";
		values[4][0] = "FORCAST";
		values[5][0] = "Gunning Fog Index";
		values[6][0] = "Läsbarhetsindex (LIX)";
		values[7][0] = "Simple Measure of Gobbledygook (SMOG)";

		String[] colnames = {"Readability Measure", "Score"};
		
		// construct "sub-models"
		tableModel = new ReadOnlyTableModel(values,colnames);
		documentModel = new PlainDocument();
		
		// default readability scores: empty
		resetResults();
		
	}
	
	/**
	 * @return the model for JTable
	 */
	protected TableModel getTableModel() {
		return tableModel;
	}

	/**
	 * @return the model for JTextArea
	 */
	protected Document getDocumentModel() {
		return documentModel;
	}

	/**
	 * Computes the readability scores and updates the results table
	 */
	protected void computeScores() {
		
		String text = "";
		
		// obtain text from the model
		try {
			text = documentModel.getText(0, documentModel.getLength());
		} catch (BadLocationException e) {
			JOptionPane.showMessageDialog(null, "Internal Error!", 
					"Readability Application", JOptionPane.ERROR_MESSAGE);
		}
		
		// if the text box is empty, set results to empty
		if ( text.trim().equals("") ) {
			resetResults();
			return;
		}
		
		// there seems to be some text, so lets go for computing the scores...
		Readability r = new Readability(text);
		
		tableModel.setValueAt(format.format(r.calcARI()),         0, 1);
		tableModel.setValueAt(format.format(r.calcColemanLiau()), 1, 1);
		tableModel.setValueAt(format.format(r.calcKincaid()),     2, 1);
		tableModel.setValueAt(format.format(r.calcFlesch()),      3, 1);
		tableModel.setValueAt(format.format(r.calcFORCAST()),     4, 1);
		tableModel.setValueAt(format.format(r.calcFog()),         5, 1);
		tableModel.setValueAt(format.format(r.calcLIX()),         6, 1);
		tableModel.setValueAt(format.format(r.calcSMOG()),        7, 1);
		
		
	}
	
	/**
	 * Empties the results table.
	 */
	protected void resetResults() {
		
		int rows = tableModel.getRowCount();
		for ( int y = 0 ; y < rows; y++ ) {
			tableModel.setValueAt("",  y, 1);
		}
		
	}
	

}

/*
Phantom Readability Library for Java
Copyright (C) 2009 Niels Ott

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/


package de.drni.readability.demo.gui;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;
import javax.swing.WindowConstants;
import javax.swing.table.TableModel;

/**
 * A Swing Component that contains a text field and a result table containing
 * readability scores computed from the text on button-click. The motivation for
 * having the functionality of an entire frame in a component is to be
 * able to use it both in a frame (window) and in an applet.
 * 
 * @version $Id: ReadabilityPanel.java 593 2009-07-14 13:37:55Z nott@SFS.UNI-TUEBINGEN.DE $
 * 
 */
/*
* This code was edited or generated using CloudGarden's Jigloo
* SWT/Swing GUI Builder, which is free for non-commercial
* use. If Jigloo is being used commercially (ie, by a corporation,
* company or business for any purpose whatever) then you
* should purchase a license for each developer using Jigloo.
* Please visit www.cloudgarden.com for details.
* Use of Jigloo implies acceptance of these licensing terms.
* A COMMERCIAL LICENSE HAS NOT BEEN PURCHASED FOR
* THIS MACHINE, SO JIGLOO OR THIS CODE CANNOT BE USED
* LEGALLY FOR ANY CORPORATE OR COMMERCIAL PURPOSE.
*/
public class ReadabilityPanel extends javax.swing.JPanel {

	private static final long serialVersionUID = 2458885652813261859L;
	private JScrollPane jScrollPane2;
	private JButton computeButton;
	private JLabel jLabel1;
	private JTextArea theTextArea;
	private JButton jButton1;
	private JScrollPane jScrollPane1;
	private JTable resultsTable;
	private PanelModel model;
	
	public void setTextAndCompute(String text) {
		
		theTextArea.setText(text);
		model.computeScores();
		
	}

	/**
	* Auto-generated main method to display this 
	* JPanel inside a new JFrame.
	*/
	public static void main(String[] args) {
		JFrame frame = new JFrame();
		frame.getContentPane().add(new ReadabilityPanel());
		frame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		frame.pack();
		frame.setVisible(true);
	}
	
	public ReadabilityPanel() {
		super();
		model = new PanelModel();
		initGUI();
	}
	
	@SuppressWarnings("static-access")
	private void initGUI() {
		try {
			this.setLayout(null);
			this.setPreferredSize(new java.awt.Dimension(546, 478));
			this.setDefaultLocale(new java.util.Locale("en"));
			{
				jScrollPane2 = new JScrollPane();
				this.add(jScrollPane2);
				jScrollPane2.setBounds(18, 281, 505, 169);
				{
					TableModel jTable1Model = model.getTableModel();
					resultsTable = new JTable();
					jScrollPane2.setViewportView(resultsTable);
					resultsTable.setModel(jTable1Model);
				}
			}
			{
				jScrollPane1 = new JScrollPane();
				this.add(jScrollPane1);
				jScrollPane1.setBounds(18, 38, 505, 183);
				{
					theTextArea = new JTextArea(model.getDocumentModel());
					jScrollPane1.setViewportView(theTextArea);
					theTextArea.setLineWrap(true);
				}
			}
			{
				computeButton = new JButton();
				//theTextArea.setNextFocusableComponent(computeButton);
				theTextArea.setWrapStyleWord(true);
				this.add(computeButton);
				computeButton.setText("Compute readability scores");
				computeButton.setBounds(58, 239, 239, 22);
				computeButton.setDefaultLocale(new java.util.Locale("en"));
				computeButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent evt) {
						model.computeScores();
					}
				});
			}
			{
				jLabel1 = new JLabel();
				this.add(jLabel1);
				jLabel1.setText("Enter (English) text here:");
				jLabel1.setBounds(18, 12, 505, 15);
				jLabel1.setLocale(new java.util.Locale("en"));
				jLabel1.setHorizontalAlignment(SwingConstants.CENTER);
			}
			{
				jButton1 = new JButton();
				//computeButton.setNextFocusableComponent(jButton1);
				this.add(jButton1);
				jButton1.setText("Clear text");
				jButton1.setBounds(330, 239, 143, 22);
				//jButton1.setNextFocusableComponent(resultsTable);
				jButton1.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent evt) {
						theTextArea.setText("");
						model.resetResults();
					}
				});
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}

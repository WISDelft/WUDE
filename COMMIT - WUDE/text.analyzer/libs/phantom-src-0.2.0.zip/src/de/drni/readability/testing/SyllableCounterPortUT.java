/*
Phantom Readability Library for Java
Copyright (C) 2009 Niels Ott

This very file is adapted from Java Fathom by Larry Ogrodnek which
has been released under the Perl license allowing for re-releasing it 
under the terms of the GPL.

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/


package de.drni.readability.testing;

import java.util.HashMap;

import de.drni.readability.phantom.analysis.SyllableCounter;
import de.drni.readability.phantom.analysis.SyllableCounterPort;
import junit.framework.TestCase;

/**
 * Unit test that checks with a 500 words word list that
 * {@link SyllableCounterPort} works like the Perl version does.
 * There is no other check for correctness than the comparison
 * to the Perl version. 
 * <p>
 * This class contains data from <a href="http://wordlist.sourceforge.net/">Kevin's Word</a> list page's
 * ispell word list.
 * 
 * @author Niels Ott
 * @version $Id: SyllableCounterPortUT.java 593 2009-07-14 13:37:55Z nott@SFS.UNI-TUEBINGEN.DE $
 */
public class SyllableCounterPortUT extends TestCase {
	
	private HashMap<String, Integer> produceTestData() {
		
		// this is a list of 500 random words taken from
		// the ispell word list on Kevin's Word list page
		// http://wordlist.sourceforge.net/
		// (taken from the files american.*)
		// 
		// For each word, the syllable count as determined
		// by Laura Kassner's Perl module is given.
		// This is like a "gold standard" for testing.
		HashMap<String, Integer> data = new HashMap<String, Integer>();
		data.put("houselings", 2);
		data.put("appetizements", 4);
		data.put("enolizes", 4);
		data.put("vitriolizations", 5);
		data.put("scrutinizingly", 5);
		data.put("glottalization", 5);
		data.put("acclimatizable", 6);
		data.put("sanitizer", 4);
		data.put("maternalizes", 5);
		data.put("Unitarianizes", 7);
		data.put("acknowledgments", 4);
		data.put("localizables", 5);
		data.put("engrams", 2);
		data.put("Occidentalizing", 6);
		data.put("platinize", 3);
		data.put("phoneticizations", 6);
		data.put("peptizable's", 4);
		data.put("gram's", 1);
		data.put("ketonization", 5);
		data.put("juvenilizes", 5);
		data.put("gutturalized", 4);
		data.put("popularizing", 5);
		data.put("mislabeled", 3);
		data.put("dramatizes", 4);
		data.put("Gaelicizes", 4);
		data.put("palladiumizes", 6);
		data.put("canceling", 3);
		data.put("uncivilizes", 5);
		data.put("processionizes", 5);
		data.put("enthronization", 5);
		data.put("equalization", 5);
		data.put("galvanization's", 5);
		data.put("medievalizes", 5);
		data.put("empaneling", 4);
		data.put("officialize", 4);
		data.put("stylized", 2);
		data.put("apostrophizing", 5);
		data.put("groveling", 3);
		data.put("presympathizes", 5);
		data.put("bonderize", 3);
		data.put("laterization's", 5);
		data.put("disenamor", 4);
		data.put("pearlizing", 3);
		data.put("savory", 3);
		data.put("dramatizers", 4);
		data.put("centimeter", 4);
		data.put("flavorlesses", 4);
		data.put("rhapsodize", 3);
		data.put("specialty's", 3);
		data.put("neutralizer", 4);
		data.put("Japanizing", 4);
		data.put("desynchronized", 4);
		data.put("vaporlesses", 4);
		data.put("tumors", 2);
		data.put("sterilized", 3);
		data.put("organizationists", 6);
		data.put("synchronizable", 5);
		data.put("unenergized", 4);
		data.put("municipalizations", 7);
		data.put("civilization's", 5);
		data.put("intellectualization", 8);
		data.put("multicolor", 4);
		data.put("centerables", 4);
		data.put("resolemnize", 4);
		data.put("epicenter", 4);
		data.put("lionizer", 3);
		data.put("Syrianizes", 5);
		data.put("unapostatizeds", 6);
		data.put("antilabors", 4);
		data.put("Francize", 2);
		data.put("ironizes", 4);
		data.put("ductilizes", 4);
		data.put("funeralizes", 5);
		data.put("unmesmerizes", 5);
		data.put("policizers", 4);
		data.put("enamors", 3);
		data.put("economized", 4);
		data.put("muscularize", 4);
		data.put("ethnicize", 3);
		data.put("theatergoer", 3);
		data.put("miraculizing", 5);
		data.put("poetized", 3);
		data.put("priorization", 4);
		data.put("unlocalizable's", 6);
		data.put("elementalize", 5);
		data.put("uncivilizedness", 6);
		data.put("discolorment", 4);
		data.put("cosmopolitanization's", 8);
		data.put("nationalizers", 5);
		data.put("aphorizes", 4);
		data.put("asynchronize", 4);
		data.put("adrenalizes", 5);
		data.put("lustered", 2);
		data.put("dematerializes", 7);
		data.put("semihonors", 4);
		data.put("impersonalizes", 6);
		data.put("periodize", 4);
		data.put("amorphization", 5);
		data.put("Ottomanizations", 6);
		data.put("trillionizes", 4);
		data.put("communalizes", 5);
		data.put("semimercerizeds", 6);
		data.put("packetize", 3);
		data.put("cancelous", 3);
		data.put("modularized", 4);
		data.put("behavioral", 5);
		data.put("precivilizations", 6);
		data.put("esthetes", 2);
		data.put("enamelists", 4);
		data.put("potentializations", 6);
		data.put("Balkanizations", 5);
		data.put("glamorizer", 4);
		data.put("fraternization", 5);
		data.put("unsystematized", 5);
		data.put("Tuscanizes", 4);
		data.put("cosmopolitanizations", 8);
		data.put("kidnaping's", 3);
		data.put("unpoeticizeds", 6);
		data.put("sacramentizes", 5);
		data.put("unparceled", 3);
		data.put("itemizing", 4);
		data.put("oxidizes", 4);
		data.put("lunatizes", 4);
		data.put("maneuverability", 7);
		data.put("isomerizes", 5);
		data.put("immortalizer", 5);
		data.put("regularizations", 6);
		data.put("dimensionalizes", 6);
		data.put("particularizations", 7);
		data.put("fantasizer", 4);
		data.put("martyrize", 3);
		data.put("unplagiarizeds", 6);
		data.put("prioritizer", 5);
		data.put("apostrophizes", 5);
		data.put("outhumored", 3);
		data.put("Egyptianization's", 6);
		data.put("sectionalizing", 5);
		data.put("castorized's", 3);
		data.put("peptization's", 4);
		data.put("center", 2);
		data.put("unenamoreds", 5);
		data.put("marsupialize", 5);
		data.put("Sanskritize", 3);
		data.put("Afrikanerizing", 6);
		data.put("sepulcher's", 3);
		data.put("destalinizing", 5);
		data.put("demeanors", 3);
		data.put("formalizing", 4);
		data.put("Unitarianize", 6);
		data.put("vaporizations", 5);
		data.put("semiorganizeds", 6);
		data.put("unilateralizes", 7);
		data.put("decarburization", 6);
		data.put("nonspecialized", 4);
		data.put("anesthetized", 4);
		data.put("lichenizes", 4);
		data.put("intercrystallization", 7);
		data.put("fertilizational", 6);
		data.put("refueling", 4);
		data.put("unsympathizingly", 6);
		data.put("homogenize", 4);
		data.put("quarreler", 3);
		data.put("anodizes", 4);
		data.put("semioxidized's", 5);
		data.put("Molochizes", 4);
		data.put("devocalize", 4);
		data.put("mesmerizes", 4);
		data.put("septicization", 5);
		data.put("logorrheas", 3);
		data.put("defunctionalize", 5);
		data.put("minimizers", 4);
		data.put("homeopathy", 3);
		data.put("carbonizers", 4);
		data.put("categorizers", 5);
		data.put("precancelation", 5);
		data.put("Vietnamize", 3);
		data.put("Italianizations", 7);
		data.put("anemia's", 4);
		data.put("weaseled", 2);
		data.put("channelize", 3);
		data.put("outsavoring", 4);
		data.put("equestrianizes", 6);
		data.put("policizes", 4);
		data.put("revelationizes", 6);
		data.put("hyalinizations", 5);
		data.put("deregulationize", 6);
		data.put("visualizers", 5);
		data.put("pauperizers", 4);
		data.put("futurize", 3);
		data.put("acclimatizables", 6);
		data.put("theatergoers", 3);
		data.put("rivalesses", 4);
		data.put("botanizes", 4);
		data.put("suberizations", 5);
		data.put("pantheonization", 5);
		data.put("superemphasize", 5);
		data.put("uncivilizable's", 6);
		data.put("parasitizes", 5);
		data.put("apologizers", 5);
		data.put("metalize", 3);
		data.put("outmaneuvers", 4);
		data.put("cartelizations", 5);
		data.put("randomized", 3);
		data.put("initializers", 5);
		data.put("etherize", 3);
		data.put("checkbook", 2);
		data.put("colorant", 3);
		data.put("vulcanizable", 5);
		data.put("serialization", 6);
		data.put("unauthorized", 4);
		data.put("vulcanizate", 4);
		data.put("mediatized", 4);
		data.put("lichenization", 5);
		data.put("sailorizing's", 4);
		data.put("Hellenize", 3);
		data.put("intercolonization", 7);
		data.put("honoring", 3);
		data.put("economizing", 5);
		data.put("energization", 5);
		data.put("rumorers", 3);
		data.put("antisiphon", 4);
		data.put("regalvanization's", 6);
		data.put("commercialized", 4);
		data.put("counselor", 3);
		data.put("rumors", 2);
		data.put("angularization", 6);
		data.put("extemporized", 4);
		data.put("prejudgment's", 3);
		data.put("homologizer", 5);
		data.put("analogism's", 4);
		data.put("powderizers", 4);
		data.put("Londonization's", 5);
		data.put("glycerolize", 4);
		data.put("tartarize", 3);
		data.put("Hellenizing", 4);
		data.put("undefenses", 4);
		data.put("recolonizations", 6);
		data.put("baconize", 3);
		data.put("machinizes", 4);
		data.put("color's", 2);
		data.put("atomizability", 7);
		data.put("infinitizes", 5);
		data.put("formulized", 3);
		data.put("recognizability", 7);
		data.put("unpracticed", 3);
		data.put("mortarize", 3);
		data.put("channeled", 2);
		data.put("enthronize", 3);
		data.put("Canadianizes", 6);
		data.put("mineralizes", 5);
		data.put("unnormalizes", 5);
		data.put("recognizably", 5);
		data.put("cordializes", 5);
		data.put("immortalizable", 6);
		data.put("organizing", 4);
		data.put("photosynthesizes", 6);
		data.put("palletization", 5);
		data.put("civilizational's", 6);
		data.put("vassalize", 3);
		data.put("collectivizes", 5);
		data.put("ozonizers", 4);
		data.put("neutralizing", 4);
		data.put("tittupy", 3);
		data.put("uncrystallized", 4);
		data.put("modernizable's", 5);
		data.put("eulogization's", 5);
		data.put("heathenizes", 4);
		data.put("boulevardize", 4);
		data.put("hamletize", 3);
		data.put("communizing", 4);
		data.put("analyzable", 5);
		data.put("categorized", 4);
		data.put("Romanizing", 4);
		data.put("kilograms", 3);
		data.put("singularizes", 5);
		data.put("etymologizing", 6);
		data.put("parameterizations", 7);
		data.put("hypercivilizations", 7);
		data.put("clamorer", 3);
		data.put("prelatize", 3);
		data.put("sabering", 3);
		data.put("clamorer's", 3);
		data.put("quarrelers", 3);
		data.put("caroler", 3);
		data.put("caracoled", 3);
		data.put("palatize", 3);
		data.put("popularize", 4);
		data.put("functionalizes", 5);
		data.put("dispapalizes", 5);
		data.put("antioxidizing's", 6);
		data.put("gynecocrat", 4);
		data.put("incognizant", 4);
		data.put("orthopedic", 4);
		data.put("honorers", 3);
		data.put("depersonalization's", 7);
		data.put("appetizers", 4);
		data.put("barbarianizes", 6);
		data.put("discolorization's", 6);
		data.put("minimizes", 4);
		data.put("musicalization", 6);
		data.put("refertilizes", 5);
		data.put("aromatizes", 5);
		data.put("dialyzer", 4);
		data.put("Bessemerize", 4);
		data.put("deindustrialize", 5);
		data.put("humanizer", 4);
		data.put("denaturize", 4);
		data.put("favoringly", 4);
		data.put("lumbarizations", 5);
		data.put("overcentralizes", 6);
		data.put("scandalization's", 5);
		data.put("ebonizes", 4);
		data.put("nonschematized", 4);
		data.put("reauthorization's", 6);
		data.put("veteranizes", 5);
		data.put("eroticized", 4);
		data.put("sonantized", 3);
		data.put("fervor's", 2);
		data.put("dichotomizing", 5);
		data.put("absolutization", 6);
		data.put("formularizing", 5);
		data.put("crystallizable's", 5);
		data.put("agnizes", 3);
		data.put("bacterize", 3);
		data.put("unsecularized", 5);
		data.put("structuralize", 4);
		data.put("vitalized", 3);
		data.put("skepticize", 3);
		data.put("underoxidize", 5);
		data.put("airfoils", 2);
		data.put("gynecologies", 5);
		data.put("colorcaster", 4);
		data.put("overrationalizes", 7);
		data.put("refertilization", 6);
		data.put("colorama", 4);
		data.put("demythologizing", 6);
		data.put("theologizing", 4);
		data.put("chloroformization's", 6);
		data.put("checkbooks", 2);
		data.put("summarized", 3);
		data.put("professionalizes", 6);
		data.put("honor", 2);
		data.put("acculturize", 4);
		data.put("theorizations", 4);
		data.put("equalizer", 4);
		data.put("chloroformization", 6);
		data.put("signaling", 3);
		data.put("neighborlikes", 3);
		data.put("disheveled", 3);
		data.put("womanizes", 4);
		data.put("venomization", 5);
		data.put("patronization's", 5);
		data.put("cinematize", 4);
		data.put("lichenize", 3);
		data.put("recognizes", 4);
		data.put("modalizes", 4);
		data.put("nanometer", 4);
		data.put("amortizations", 5);
		data.put("overdoctrinize", 5);
		data.put("Quakerizations", 5);
		data.put("mercerizes", 4);
		data.put("sentineling", 4);
		data.put("vocalizers", 4);
		data.put("pasteurize", 3);
		data.put("peroxidizement's", 5);
		data.put("Slavizations", 4);
		data.put("Londonization", 5);
		data.put("anticizes", 4);
		data.put("ardor's", 2);
		data.put("collectivize", 4);
		data.put("fibered", 2);
		data.put("uncategorized", 5);
		data.put("socialize", 3);
		data.put("nonnitrogenized's", 5);
		data.put("summarizations", 5);
		data.put("baconizes", 4);
		data.put("magnetization's", 5);
		data.put("reveler", 3);
		data.put("insurrectionize", 5);
		data.put("testimonialize", 6);
		data.put("outcaviling", 4);
		data.put("attitudinize", 5);
		data.put("denaturization's", 6);
		data.put("paralyzedly", 5);
		data.put("filmize", 2);
		data.put("vectorizers", 4);
		data.put("Mediterraneanization's", 8);
		data.put("apotheosize", 4);
		data.put("unscepter's", 3);
		data.put("initializations", 6);
		data.put("motorizations", 5);
		data.put("idolizers", 4);
		data.put("paneled", 2);
		data.put("horrorize", 3);
		data.put("infidelizes", 5);
		data.put("scrutinizinglies", 5);
		data.put("savorlesses", 4);
		data.put("morselization's", 5);
		data.put("unharbor", 3);
		data.put("tellurizing", 4);
		data.put("rationalizing", 5);
		data.put("slenderizing", 4);
		data.put("doctorize", 3);
		data.put("concertizes", 4);
		data.put("productizing", 4);
		data.put("unlabored", 3);
		data.put("unparticularized", 6);
		data.put("disillusionizes", 6);
		data.put("nonrealizations", 5);
		data.put("nonsensitized", 4);
		data.put("unapologizing", 6);
		data.put("defense", 2);
		data.put("italicizing", 5);
		data.put("historicized", 4);
		data.put("lysogenize", 4);
		data.put("hyphenizes", 4);
		data.put("spiralization", 5);
		data.put("dimerizations", 5);
		data.put("decimalize", 4);
		data.put("behaviors", 4);
		data.put("sterilizers", 4);
		data.put("excursionizes", 5);
		data.put("professionizes", 5);
		data.put("bantamizes", 4);
		data.put("vermeiled", 2);
		data.put("revolutionizement", 6);
		data.put("unmotorized", 4);
		data.put("revalorizations", 6);
		data.put("localized", 3);
		data.put("vitaminizes", 5);
		data.put("biographize", 4);
		data.put("totaler's", 3);
		data.put("digitalizations", 6);
		data.put("overurbanizations", 7);
		data.put("analyzers", 4);
		data.put("fertilizations", 5);
		data.put("noncrystallizable's", 6);
		data.put("ketonizes", 4);
		data.put("pemmicanize", 4);
		data.put("oxygenize", 4);
		data.put("albuminization", 6);
		data.put("silicidizes", 5);
		data.put("disenthralls", 3);
		data.put("aggrandizer", 4);
		data.put("amalgamization", 6);
		data.put("soberizes", 4);
		data.put("causticize", 3);
		data.put("civilianization", 7);
		data.put("Grecianizes", 5);
		data.put("recapitalized", 5);
		data.put("unsentimentalizes", 7);
		data.put("chromizes", 3);
		data.put("overfavors", 4);
		data.put("centralization's", 5);
		data.put("unphilosophized", 5);
		data.put("odorless", 3);
		data.put("Berlinizes", 4);
		data.put("micronizations", 5);
		data.put("voltizes", 3);
		data.put("racemizes", 4);
		data.put("positivizes", 5);
		data.put("queuing", 1);
		data.put("humanitarianizes", 8);
		data.put("pidginizes", 4);
		data.put("mercerized", 3);
		data.put("psychologized", 4);
		data.put("synchronizers", 4);
		data.put("teaselers", 3);
		data.put("curatize", 3);
		data.put("gelatinizers", 5);
		data.put("journalizes", 4);
		data.put("unmercerized", 4);
		data.put("remonetized", 4);
		data.put("anathematizes", 6);
		data.put("summarizers", 4);
		data.put("partisanizes", 5);
		data.put("civilizationals", 6);
		data.put("formularized", 4);
		data.put("reorganizes", 5);
		data.put("overspecializations", 7);
		data.put("underutilization", 7);
		data.put("satirizable", 5);
		data.put("chemicalization's", 6);
		data.put("Peruvianizes", 6);
		data.put("idolizing", 4);
		data.put("renormalized", 4);
		data.put("concretizations", 5);
		data.put("depolarizing", 5);
		data.put("diabolization", 6);
		data.put("absolutizes", 5);
		data.put("customizers", 4);
		data.put("satinize", 3);
		data.put("tenementizations", 6);
		data.put("proletarianize", 6);
		data.put("lionizes", 3);
		data.put("hovelers", 3);
		data.put("fascistizes", 4);
		data.put("sniveler", 3);
		data.put("pogromize", 3);
		data.put("denominationalize", 7);
		
		return data;
	}
	
	/**
	 * A simple test counting the syllables of one word.
	 */
	public void testSimple1() {
		SyllableCounter sc = new SyllableCounterPort();
		assertEquals(2, sc.countSyllables("Hello"));
	}

	/**
	 * The test operating on the 500 syllables list.
	 */
	public void testCountSyllables() {
		
		SyllableCounter sc = new SyllableCounterPort();
		HashMap<String, Integer> data = produceTestData();

		for ( String word : data.keySet() ) {
			int mySyll = sc.countSyllables(word);
			int expectSyll = data.get(word);
			
			if ( mySyll != expectSyll) {
				fail("Word \"" + word + "\": " +
						"expected " + expectSyll + 
						" syllables but got " + mySyll + ". Aborting test.");
			}
		}
	}

}
